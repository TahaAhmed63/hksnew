import MyIcon from '../../assets/homepage-images/pk.svg';

const HomeMaplic = () => {
  return (
    <div className='container-fluid'>
        <div className="row">
            <div className="col-12">
                 <div className='my-md-5 maplic-sec'>
                    <h1 className='text-center interbold'>HKS GLOBAL PETROLEUM BUSINESS NETWORK</h1>
                        <MyIcon />
                </div>
            </div>
        </div>

    </div>
  );
};

export default HomeMaplic;
